# FlyMew_RC
RC (Radio Control) for FlyMew hardware (RYA 2017)

FlyMew platform:

Ardupilot: https://github.com/PIFClub/FlyMew_Ardupilot.git

Radio Control: https://github.com/PIFClub/FlyMew_RC.git

Electronic: https://github.com/PIFClub/FlyMew_Electronic.git
