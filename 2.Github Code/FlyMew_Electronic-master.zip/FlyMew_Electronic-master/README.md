# FlyMew_Electronic
Hardware for FlyMeo platform (RYA 2017)

FlyMew platform:

Ardupilot: https://github.com/PIFClub/FlyMew_Ardupilot.git

Radio Control: https://github.com/PIFClub/FlyMew_RC.git

Electronic: https://github.com/PIFClub/FlyMew_Electronic.git
